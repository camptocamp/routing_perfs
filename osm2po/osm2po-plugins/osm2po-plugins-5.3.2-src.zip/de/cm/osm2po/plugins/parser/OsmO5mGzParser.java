/* 
   Copyright (c) 2012 Carsten Moeller, Pinneberg, Germany. <info@osm2po.de>

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as 
   published by the Free Software Foundation, either version 3 of the 
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
   
   $Id: OsmO5mGzParser.java 4479 2017-08-06 13:12:51Z carsten $
*/

package de.cm.osm2po.plugins.parser;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;

import de.cm.osm2po.Config;
import de.cm.osm2po.converter.parser.OsmParserHandler;

public class OsmO5mGzParser extends OsmO5mParser {

    @Override
    public void open(InputStream zipInputStream,
            OsmParserHandler osmParserHandler, Config config) {
        try {
            InputStream is = new GZIPInputStream(
                    new BufferedInputStream(zipInputStream));
            super.open(is, osmParserHandler, config);
            
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
