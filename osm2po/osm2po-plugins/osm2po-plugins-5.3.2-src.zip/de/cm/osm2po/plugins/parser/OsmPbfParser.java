/* 
   Copyright (c) 2011 Carsten Moeller, Pinneberg, Germany. <info@osm2po.de>

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as 
   published by the Free Software Foundation, either version 3 of the 
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
   
   $Id: OsmPbfParser.java 4423 2017-04-16 08:26:55Z carsten $
*/

package de.cm.osm2po.plugins.parser;

import java.io.InputStream;
import java.util.List;

import com.google.protobuf.Descriptors.EnumValueDescriptor;

import crosby.binary.BinaryParser;
import crosby.binary.Osmformat.DenseNodes;
import crosby.binary.Osmformat.HeaderBlock;
import crosby.binary.Osmformat.Node;
import crosby.binary.Osmformat.Relation;
import crosby.binary.Osmformat.Way;
import crosby.binary.file.BlockInputStream;
import de.cm.osm2po.Config;
import de.cm.osm2po.converter.parser.OsmParser;
import de.cm.osm2po.converter.parser.OsmParserHandler;

public class OsmPbfParser extends BinaryParser implements OsmParser {

    private OsmParserHandler osmParserHandler;
    private BlockInputStream blockInputStream;
    
    private boolean isFirstWay = true;
    private boolean isFirstRelation = true;
    private boolean arbitrary;
    
    @Override
    public void open(InputStream pbfInputStream,
            OsmParserHandler osmParserHandler, Config config) {
        this.blockInputStream = new BlockInputStream(pbfInputStream, this);
        this.osmParserHandler = osmParserHandler;

        this.arbitrary = Boolean.valueOf(
                config.getProperty("parser.arbitrary"));
    }
    

    @Override
    public void parse() {
        try {
            this.blockInputStream.process();
            
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void close() {
        try {
            this.blockInputStream.close();
            
            this.isFirstWay = true;
            this.isFirstRelation = true;
            
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void parse(HeaderBlock header) {
    }

    @Override
    protected void parseNodes(List<Node> nodes) {
        if (nodes != null && nodes.size() > 0) {
            throw new RuntimeException(this.getClass().getName()
                    + " only supports DenseNodes");
        }
    }

    @Override
    public void complete() {
        if (!this.arbitrary)
            this.osmParserHandler.closeRelationProcessing();
    }

    
    @Override
    protected void parseDense(DenseNodes nodes) {
        long lastId = 0;
        long lastLat = 0;
        long lastLon = 0;
        int kv = 0;
        int kvSize = nodes.getKeysValsCount();
        
        
        for (int i = 0; i < nodes.getIdCount(); i++) {
            long id = nodes.getId(i) + lastId;
            long lat = nodes.getLat(i) + lastLat;
            long lon = nodes.getLon(i) + lastLon;
            
            double dlat = this.parseLat(lat);
            double dlon = this.parseLon(lon);

            this.osmParserHandler.onNode(id, dlat, dlon);
            
            // Delta Encoding
            lastId = id;
            lastLat = lat;
            lastLon = lon;

            int key = kv < kvSize ? nodes.getKeysVals(kv++) : 0;
            while (key != 0) {
                int val = nodes.getKeysVals(kv++);
                String strKey = this.getStringById(key);
                String strVal = this.getStringById(val);
                this.osmParserHandler.onNodeTag(strKey, strVal);
                
                // No range check here, we trust the documented pattern
                // ((<keyid> <valid>)* '0' )*
                key = nodes.getKeysVals(kv++);
            }

            this.osmParserHandler.onNodeComplete();
        }

    }

    @Override
    protected void parseWays(List<Way> ways) {
        if (ways.size() > 0) {
            
            if (this.isFirstWay) {
                if (!this.arbitrary)
                    this.osmParserHandler.closeNodeProcessing();
                this.isFirstWay = false;
            }

            for (Way way : ways) {
                
                long id = way.getId();
                this.osmParserHandler.onWay(id);

                long lastRef = 0;
                for (int j = 0; j < way.getRefsCount(); j++) {
                    long refId = way.getRefs(j) + lastRef; // Delta-Encoded
                    this.osmParserHandler.onWayNdRef(refId);
                    lastRef = refId;
                }
                
                for (int i = 0; i < way.getKeysCount(); i++) {
                    int key = way.getKeys(i);
                    int val = way.getVals(i);
                    String strKey = this.getStringById(key);
                    String strVal = this.getStringById(val);
                    this.osmParserHandler.onWayTag(strKey, strVal);
                }
                
                this.osmParserHandler.onWayComplete();
            }
        }
    }
    
    @Override
    protected void parseRelations(List<Relation> rels) {
        
        if (rels.size() > 0) {
            if (this.isFirstRelation) {
                this.isFirstRelation = false;
                if (!this.arbitrary)
                    this.osmParserHandler.closeWayProcessing();
            }
            
            for (Relation rel : rels) {
                long id = rel.getId();
                this.osmParserHandler.onRelation(id);
                
                long lastRef = 0;
                for (int i = 0; i < rel.getMemidsCount(); i++) {
                    
                    EnumValueDescriptor descriptor = rel.getTypes(i).getValueDescriptor();
                    String strType = descriptor.getName().toLowerCase();

                    long ref = rel.getMemids(i) + lastRef;

                    int role = rel.getRolesSid(i);
                    String strRole = this.getStringById(role);
                    
                    this.osmParserHandler.onRelationMember(strType, ref, strRole);
                    
                    lastRef = ref;
                }
                
                for (int i = 0; i < rel.getKeysCount(); i++) {
                    int key = rel.getKeys(i);
                    int val = rel.getVals(i);
                    String strKey = this.getStringById(key);
                    String strVal = this.getStringById(val);
                    this.osmParserHandler.onRelationTag(strKey, strVal);
                }
                
                this.osmParserHandler.onRelationComplete();
            }
        }
    }
    
}
