/* 
   Copyright (c) 2012 Carsten Moeller, Pinneberg, Germany. <info@osm2po.de>

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as 
   published by the Free Software Foundation, either version 3 of the 
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
   
   $Id: OsmO5mParser.java 4423 2017-04-16 08:26:55Z carsten $
*/

package de.cm.osm2po.plugins.parser;

import static de.cm.osm2po.primitives.VarNum.readSigned;
import static de.cm.osm2po.primitives.VarNum.readUnsigned;
import static de.cm.osm2po.primitives.VarString.readZeroDelimeted;
import static java.lang.Integer.toHexString;

import java.io.InputStream;
import java.util.Date;

import de.cm.osm2po.Config;
import de.cm.osm2po.converter.parser.OsmParser;
import de.cm.osm2po.converter.parser.OsmParserHandler;
import de.cm.osm2po.logging.Log;
import de.cm.osm2po.model.LatLon;
import de.cm.osm2po.primitives.InStream;
import de.cm.osm2po.primitives.InStreamAdapter;
import de.cm.osm2po.primitives.VarString;

public class OsmO5mParser implements OsmParser {

    private final static String FORMAT = "o5m2";

    private final static byte START      = (byte) 0xff;
    private final static byte RESET      = (byte) 0xff;
    private final static byte END        = (byte) 0xfe;
    private final static byte NODE       = (byte) 0x10;
    private final static byte WAY        = (byte) 0x11;
    private final static byte RELATION   = (byte) 0x12;
    private final static byte BBOX       = (byte) 0xdb;
    private final static byte TIMESTAMP  = (byte) 0xdc;
    private final static byte HEADER     = (byte) 0xe0;
    private final static byte SYNC       = (byte) 0xee;
    private final static byte JUMP       = (byte) 0xef;
    
    private final static VarString REL_NODE = new VarString("0");
    private final static VarString REL_WAY  = new VarString("1");
    private final static VarString REL_REL  = new VarString("2");
    
    private InStream inStream;
    private OsmParserHandler handler;
    private Log log;
    
    private VarString vs1 = new VarString(); // Holder for StringPair
    private VarString vs2 = new VarString(); // Holder for StringPair
    
    private VarString vs1Ptr; // Pointer to StringPair key after parsing 
    private VarString vs2Ptr; // Pointer to StringPair val after parsing
    
    private VarString[] pairs1 = new VarString[15000];
    private VarString[] pairs2 = new VarString[15000];
    private int pairIdx;
    
    private long deltaNodeId;
    private long deltaNodeLat;
    private long deltaNodeLon;
    private long deltaTimeStamp;
    private long deltaChangeSet;
    private long deltaWayId;
    private long deltaWayNodeRef;
    private long deltaRelationId;
    private long deltaRelationNodeRef;
    private long deltaRelationWayRef;
    private long deltaRelationRelationRef;
    
    private byte PREVTYPE;
    
    private boolean arbitrary;
    
    @Override
    public void open(InputStream inputStream,
            OsmParserHandler osmParserHandler, Config config) {
        this.inStream = new InStreamAdapter(inputStream);
        this.handler = osmParserHandler;
        this.log = config.getLog();

        this.arbitrary = Boolean.valueOf(
                config.getProperty("parser.arbitrary"));
    }

    @Override
    public void close() {
        this.inStream.close();
    }

    @Override
    public void parse() {
        if (inStream.readByte() != START)
            throw new RuntimeException("Start Byte " + START + " expected");

        while (!inStream.isEof()) {
            byte type = inStream.readByte();
            switch (type) {
            case NODE: this.parseNode(); break;
            case WAY: this.parseWay(); break;
            case RELATION: this.parseRelation(); break;
            case HEADER: this.parseHeader(); break;
            case TIMESTAMP: this.parseTimeStamp(); break;
            case BBOX: this.parseBoundingBox(); break;
            case RESET: this.reset(); break;
            case JUMP: this.jump(); break;
            case SYNC: this.sync(); break;
            case END: this.end(); break;
            default:
                log.warn("Unknown Type 0x" + toHexString(type & 0xff));
                this.skipBytes();
            }
            PREVTYPE = type;
        }
    }
    
    private void reset() {
        log.debug("Reset: PrevType was 0x"
                + Integer.toHexString(PREVTYPE & 0xFF));
        
        this.pairIdx = 0;
        
        this.deltaNodeId = 0L;
        this.deltaNodeLat = 0L;
        this.deltaNodeLon = 0L;
        this.deltaTimeStamp = 0L;
        this.deltaChangeSet = 0L;
        this.deltaWayId = 0L;
        this.deltaWayNodeRef = 0L;
        this.deltaRelationId = 0L;
        this.deltaRelationNodeRef = 0L;
        this.deltaRelationWayRef = 0L;
        this.deltaRelationRelationRef = 0L;
        
        if (NODE == PREVTYPE) {
            if (!this.arbitrary)
                this.handler.closeNodeProcessing();
        } else if (WAY == PREVTYPE) {
            if (!this.arbitrary)
                this.handler.closeWayProcessing();
        }

    }

    private void end() {
        if (PREVTYPE == RELATION) {
            if (!this.arbitrary)
                this.handler.closeRelationProcessing();
        }
    }
    
    private void parseStringPairFragment(boolean forRelRef) {
        long ref = readUnsigned(this.inStream);
        if (0L == ref) {
            if (forRelRef) {
                byte type = this.inStream.readByte();
                this.vs1.setBytes(new byte[] {type});
            } else {
                readZeroDelimeted(this.vs1, this.inStream);
            }
            readZeroDelimeted(this.vs2, this.inStream);
            this.vs1Ptr = vs1;
            this.vs2Ptr = vs2;
            if (this.vs1.length() + this.vs2.length() > 250) {
                if (log.isEnabled(Log.LEVEL_DATA))
                    log.data("Skipping StringPair\n" + this.vs1 + "=" + this.vs2);
            } else {
                if (this.pairIdx == 15000) this.pairIdx = 0;
                this.pairs1[this.pairIdx] = this.vs1.copy();
                this.pairs2[this.pairIdx] = this.vs2.copy();
                this.pairIdx++;
            }
        } else {
            int idx = (int) (this.pairIdx - ref);
            if (idx < 0) idx += 15000;
            this.vs1Ptr = this.pairs1[idx];
            this.vs2Ptr = this.pairs2[idx];
        }
    }

    private void parseTimeStamp() {
        long len = readUnsigned(this.inStream); // Length, but why?
        long pos = this.inStream.getReadIndex();
        if (len > 0) {
            long ts = readSigned(this.inStream); // in seconds since 1970
            log.debug("File TimeStamp: " + new Date(ts * 1000));
            if (this.inStream.getReadIndex() - pos != len) {
                throw new RuntimeException("TimeStamp size does not match");
            }
        }
    }

    /**
     * Parsed Version-, TimeStamp-, ChangeSet-, Author-Fragment
     * fuer jede Entity (Node, Way, Relation).
     */
    private void parseVersionFragment() {
        long version = readUnsigned(this.inStream);
        if (version != 0L) {
            this.deltaTimeStamp += readSigned(this.inStream);
            if (this.deltaTimeStamp != 0L) {
                this.deltaChangeSet += readSigned(this.inStream);
                this.parseStringPairFragment(false); // UID (StringBytes as Number), User
            }
        }
    }

    private void parseHeader() {
        this.vs1.readFromStream(this.inStream);
        log.debug("Header: " + this.vs1);
        if (!FORMAT.equals(this.vs1.toString()))
            throw new RuntimeException(FORMAT + " expected in Header");
    }
    
    private void parseBoundingBox() {
        long len = readUnsigned(this.inStream);
        if (len > 0) {
            double x1 = readSigned(this.inStream) / 1e7;
            double y1 = readSigned(this.inStream) / 1e7;
            double x2 = readSigned(this.inStream) / 1e7;
            double y2 = readSigned(this.inStream) / 1e7;
            log.debug("BoundingBox: " + new LatLon(y1, x1) + "-" + new LatLon(y2, x2));
        }
    }

    private void skipBytes() {
        long len = readUnsigned(this.inStream);
        log.warn("Skipping " + len + " bytes");
        for (int i = 0; i < len; i++) {
            this.inStream.readByte();
        }
    }
    
    private void sync() {
        log.warn("Sync not supported");
        this.skipBytes();
    }
    
    private void jump() {
        log.warn("Jump not supported");
        this.skipBytes();
    }
    
    private void parseNode() {
        long length = readUnsigned(this.inStream);
        long lastIndex = this.inStream.getReadIndex() + length;
        
        this.deltaNodeId += readSigned(this.inStream);

        this.parseVersionFragment();
        
        this.deltaNodeLon += readSigned(this.inStream);
        this.deltaNodeLat += readSigned(this.inStream);
        
        double lon = this.deltaNodeLon / 1e7;
        double lat = this.deltaNodeLat / 1e7;
        
        this.handler.onNode(this.deltaNodeId, lat, lon);
        
        // Node-Tags
        while (this.inStream.getReadIndex() < lastIndex) {
            this.parseStringPairFragment(false);
            this.handler.onNodeTag(
                    this.vs1Ptr.toString(), this.vs2Ptr.toString());
        }
        
        this.handler.onNodeComplete();
    }

    private void parseWay() {
        long length = readUnsigned(this.inStream);
        long lastIndex = this.inStream.getReadIndex() + length;
        
        this.deltaWayId += readSigned(this.inStream);
        this.handler.onWay(this.deltaWayId);

        this.parseVersionFragment();
        
        long refsLength = readUnsigned(this.inStream);
        long lastRefIndex = this.inStream.getReadIndex() + refsLength;

        // Way-Refs
        while(this.inStream.getReadIndex() < lastRefIndex) {
            this.deltaWayNodeRef += readSigned(this.inStream);
            this.handler.onWayNdRef(this.deltaWayNodeRef);
        }
        
        // Way-Tags
        while (this.inStream.getReadIndex() < lastIndex) {
            this.parseStringPairFragment(false);
            this.handler.onWayTag(
                    this.vs1Ptr.toString(), this.vs2Ptr.toString());
        }
        
        this.handler.onWayComplete();
    }
    
    
    private void parseRelation() {
        long length = readUnsigned(this.inStream);
        long lastIndex = this.inStream.getReadIndex() + length;

        this.deltaRelationId += readSigned(this.inStream);
        this.handler.onRelation(this.deltaRelationId);

        this.parseVersionFragment();
        
        long refsLength = readUnsigned(this.inStream);
        long lastRefIndex = this.inStream.getReadIndex() + refsLength;

        // Relation-Refs
        while(this.inStream.getReadIndex() < lastRefIndex) {
            long deltaRef = readSigned(this.inStream);
            
            this.parseStringPairFragment(true);
            if (REL_NODE.equals(this.vs1Ptr)) {
                this.deltaRelationNodeRef += deltaRef;
                this.handler.onRelationMember("node",
                        this.deltaRelationNodeRef, this.vs2Ptr.toString());
            } else if (REL_WAY.equals(this.vs1Ptr)) {
                this.deltaRelationWayRef += deltaRef;
                this.handler.onRelationMember("way",
                        this.deltaRelationWayRef, this.vs2Ptr.toString());
            } else if (REL_REL.equals(this.vs1Ptr)) {
                this.deltaRelationRelationRef += deltaRef;
                this.handler.onRelationMember("relation",
                        this.deltaRelationRelationRef, this.vs2Ptr.toString());
            } else {
                throw new IllegalStateException(
                        "Unknown Relation RefTyp " + this.vs1Ptr);
            }
        }
        
        // Relation-Tags
        while (this.inStream.getReadIndex() < lastIndex) {
            this.parseStringPairFragment(false);
            this.handler.onRelationTag(
                    this.vs1Ptr.toString(), this.vs2Ptr.toString());
        }
        
        this.handler.onRelationComplete();
    }
    
}
