/*
   Copyright (c) 2014 Carsten Moeller, Pinneberg, Germany. <info@osm2po.de>

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as
   published by the Free Software Foundation, either version 3 of the
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   $Id: PgPolyRelWriter.java 4578 2017-12-14 19:31:43Z carsten $
*/

package de.cm.osm2po.plugins.postp;

import static de.cm.osm2po.Config.POSTP;
import static de.cm.osm2po.misc.Utils.DF;
import static de.cm.osm2po.misc.Utils.bytesToHex;
import static de.cm.osm2po.misc.WkbUtils.toPolygonWkb;
import static de.cm.osm2po.primitives.VarString.toUTF8QuotedSqlBytes;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Date;

import de.cm.osm2po.Config;
import de.cm.osm2po.Version;
import de.cm.osm2po.converter.joiner.JoinedWaysIterator;
import de.cm.osm2po.logging.Log;
import de.cm.osm2po.model.LatLons;
import de.cm.osm2po.model.OsmPolygon;
import de.cm.osm2po.model.OsmPolygonBuilder;
import de.cm.osm2po.model.Way;
import de.cm.osm2po.postp.PostProcessor;

public class PgPolyRelWriter implements PostProcessor {

    private static final byte KOMMA = ',';
    private static final byte SEMIKOLON = ';';
    private static final byte NEWLINE = '\n';

    private Log log;

    @Override
    public void run(Config config, int index) throws Exception {
        this.log = config.getLog();

        final File dir = config.getWorkDir();
        final String prefix = config.getPrefix();

        final String tableName = (prefix + "_2po_polyrel").toLowerCase(); // Postgres-Problem
        final String fileName = prefix + "_2po_polyrel.sql";

        boolean pipeOut = Boolean.valueOf(
                config.getProperty(POSTP(index) + ".pipeOut"));

        OutputStream os = null;
        File sqlOutFile = null;
        if (pipeOut) {
            os = System.out;
            log.info("Writing results to stdout");
        } else {
            sqlOutFile = new File(dir, fileName);
            os = new BufferedOutputStream(
                    new FileOutputStream(sqlOutFile), 0x10000 /*64k*/);
            log.info("Creating sql file " + sqlOutFile.toString());
        }

        OsmPolygonBuilder polygonBuilder = new OsmPolygonBuilder(log);

        os.write((""
            + "-- Created by  : " + Version.getName() + "\n"
            + "-- Version     : " + Version.getVersion() + "\n"
            + "-- Author (c)  : Carsten Moeller - info@osm2po.de\n"
            + "-- Date        : " + new Date().toString()
            + "\n\n"
            + "SET client_encoding = 'UTF8';"
            + "\n\n"
            + "DROP TABLE IF EXISTS " + tableName + ";"
            + "\n"
            + "-- SELECT DropGeometryTable('" + tableName + "');"
            + "\n\n"
            + "CREATE TABLE " + tableName + "("
            + "id integer, osm_id bigint, osm_name character varying, "
            + "clazz integer, flags integer"
            + ");\n"
            + "SELECT AddGeometryColumn('" + tableName + "', "
            + "'geom_poly', 4326, 'POLYGON', 2);\n")
        .getBytes());

        byte[] INSERT = ("\nINSERT INTO " + tableName + " VALUES ").getBytes();

        int nWays = 0;
        for (Way way : new JoinedWaysIterator(config)) {
            polygonBuilder.collectMemberships(way);
            if (++nWays % 25000 == 0) log.progress(DF(nWays) + " ways collected");
        }

        int id = 0, g = 0;
        for (OsmPolygon polygons : polygonBuilder) {

            long osmId = polygons.getId();
            byte clazz = polygons.getClazz();
            int flags = polygons.getFlags();
            byte[] nameSql = toUTF8QuotedSqlBytes(polygons.getName(), true);

            for (LatLons[] polygon : polygons.getPolygons()) {
                String geom_poly = bytesToHex(toPolygonWkb(polygon));

                ++id;

                // Bulk inserts are shorter and faster
                if (g == 25) {
                    os.write(SEMIKOLON);
                    os.write(NEWLINE);
                    g = 0;
                }
                if (++g == 1) os.write(INSERT); else os.write(KOMMA);
                os.write(NEWLINE);

                os.write(("(" + id + ", " + osmId + ", ").getBytes());
                os.write(nameSql);
                os.write((", "  + clazz + ", " + flags
                        + ", " + "'" + geom_poly + "'" + ")").getBytes());

                if (id % 2500 == 0) log.progress(DF(id) + " Polygons written.");
            }
        }

        os.write(SEMIKOLON);
        os.write(NEWLINE);

        log.info(DF(id) + " Polygons written.");

        os.write(("\n"
            + "ALTER TABLE " + tableName + " ADD CONSTRAINT pkey_" + tableName + " PRIMARY KEY(id);\n"
            + "-- CREATE INDEX idx_" + tableName + "_geom_poly ON " + tableName
            + " USING GIST (geom_poly);\n")
            .getBytes());

        if (sqlOutFile != null) {
            os.close();
            log.info("commandline template:\n"
                    + "psql -U [username] -d [dbname] -q -f \""
                    + sqlOutFile.getAbsolutePath() + "\"");
        }
    }
}
